import { NumberFormatStyle } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { User } from '../../models/nombre_y_ape';
@Component({
  selector: 'register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  public page_title: string;
  public user: User;

  constructor() {
    this.page_title = 'Registrate!'; 
    this.user = new User(1, '', '', 0, '');
   }
  


  ngOnInit() {
    console.log('Componente funcionando');
  }

  onSubmit(form:any){
    console.log(this.user);

  }

}
