export class User{
    constructor(
        public id: number,
        public name: string,
        public surname: string,
        public age: number,
        public position: string,
    ){}
}